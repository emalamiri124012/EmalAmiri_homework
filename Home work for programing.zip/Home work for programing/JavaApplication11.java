
//import java.util.Scanner;

public class JavaApplication11 {

    public static void main(String[] args) {
//        Scanner input = new Scanner(System.in);
//        System.out.print("inter the first number :");
//        int x = input.nextInt();
//        System.out.print("inter the second number :");
//        int e = input.nextInt();

        System.out.println(" er");
      
        



    }}
        
    
