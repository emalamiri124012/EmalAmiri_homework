package desplaying.cureant.time;

import java.util.Scanner;

public class DesplayingCureantTime {

    public static void main(String[] args) {
//   int h=2;
//   int m=40;
//   int s=50;
//        System.out.print(h+":"+m+":"+s);

//int hour=1;
//int mineut=45;
//int second=15;
//        System.out.println(hour+":"+mineut+":"+second);




Scanner scanner=new Scanner(System.in);
        System.out.println("please enter the value");
int hour=scanner.nextInt();
int mineut=scanner.nextInt();
int secound=scanner.nextInt();
        System.out.println(hour+":"+mineut+":"+secound);

    }

}
