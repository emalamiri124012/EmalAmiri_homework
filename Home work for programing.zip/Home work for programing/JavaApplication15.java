package javaapplication15;

import java.util.Scanner;

public class JavaApplication15 {

    public static void main(String[] args) {
//        System.out.println("please enter the value");
//        Scanner scanner = new Scanner(System.in);
//        int x = scanner.nextInt();
//        if (x >= 0 && x <= 7) {
//            switch (x) {
//                case 0:
//                    System.out.println("this is saturday");
//                    break;
//                case 1:
//                    System.out.println("this is sunday");
//                    break;
//                case 2:
//                    System.out.println("this is monday");
//                    break;
//                case 3:
//                    System.out.println("this is tuesday");
//                    break;
//                default:System.out.println("this is  vacancy");
//                break;
//            }
//
//        } else {
//            System.out.println("you enter the false number");
//        }
    int e = 43;
      int y = (e>40)?6:48784;
    }
}
