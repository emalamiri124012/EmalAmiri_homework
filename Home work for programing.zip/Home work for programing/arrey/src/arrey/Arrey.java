package arrey;

public class Arrey {

    public static void main(String[] args) {

//Example 1:
//        String[] weekday = {"sat", "sun", "mon", "tue", "wen", "thr", "fri"};
//        System.out.println(weekday[0]);
//        System.out.println(weekday[1]);
//        System.out.println(weekday[2]);
//        System.out.println(weekday[3]);
//        System.out.println(weekday[4]);
//        System.out.println(weekday[5]);
//        System.out.println(weekday[6]);
//Example 2:
//        String[] sumeName = {"hussain", "ali", "mohammad", "ashraf", "mahdi"};
//        System.out.println(sumeName[0]);
//        System.out.println(sumeName[1]);
//        System.out.println(sumeName[2]);
//        System.out.println(sumeName[3]);
//        System.out.println(sumeName[4]);
//Example 3:
//        String[] weekday = {"sat", "sun", "mon", "tue", "wen", "thr", "fri"};
//        int x = 0;
//        while (x <= 6) {
//            System.out.println(weekday[x]);
//
//            x++;
//        }
//Example 4:
//        String[] weekday = {"sat", "sun", "mon", "the", "wen", "thr", "fri"};
//        for (int x = 0; x < 7; x++) {
//            System.out.println(weekday[x]);

//Example 5:
//        String[  ] weekday = {"sat", "sun", "mon", "the", "wen", "thr", "fri"};
//        for (String day : weekday) {
//            System.out.println(day);
//        }
int x=0;
String [ ] weekday= {"sat", "sun", "mon", "the", "wen", "thr", "fri"};
do{
    System.out.println(weekday[x]);
    while(x<=6){
        x++;
    }
}
    


