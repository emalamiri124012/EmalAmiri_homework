
package gussing.number;

import java.util.Scanner;

public class GussingNumber {

    public static void main(String[] args) {
     Scanner scanner=new Scanner(System.in);
        System.out.println("please enter the value");
     int x=scanner.nextInt();
                System.out.println(x);
         int y=(int)((Math.random()*90)+10);
        System.out.println(y);
   
     if(y<x){
         System.out.println("this number y is lower than x");
     }else if(y>x){
             System.out.println("this number y is higher than x");
     }else {
         System.out.println("this number is not incolet");
       
     }
    

    
        
    }
    
}
