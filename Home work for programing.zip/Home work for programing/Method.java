package method;

//public class Method {
//    public static void main(String[] args) {
//        double x=23;
//        double y=89;
//        double t=90;
//        double d=max(x,y,t);
//        System.out.println(d);
//    }
//        
//        
//   public static double max(double x,double y,double t){
//      double result;
//      if(x>y&&x>t)
//         result=x;
//      else if(y>x&&y>t)
//        result=y;
//      else
//          result=t;
//      return result;
//    }
//    }
//public class Method {
//
//    public static void main(String[] args) {
//
//        int e = 3;
//        int w = 78;
//        int a = 5;
//        int s = min(e, w, a);
//
//        System.out.println(s);
//
//    }
//
//    public static int min(int e, int w, int a) {
//        int r;
//        if (e < w && e < a) {
//            r = e;
//        } else if (w < e && w < a) {
//            r = w;
//        } else {
//            r = a;
//        }
//        return r;
//    }
//
//}
