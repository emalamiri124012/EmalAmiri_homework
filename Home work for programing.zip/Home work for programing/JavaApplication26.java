
package javaapplication26;

import java.util.Scanner;


public class JavaApplication26 {

 
    
    public static void main(String[] args) {
        
Scanner scanner=new Scanner(System.in);
        System.out.println("please enter the value");
int x=scanner.nextInt();
while(x<=9){
    System.out.println(x);
    x++;
}
    
    }
    
}
