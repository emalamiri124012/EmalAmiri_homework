

package javaapplication20;


 class JavaApplication20 {


    public static void main(String[] args) {

String name="My name is hussain";
        System.out.println(name);
String e="My last name is sharifi";
        System.out.println(e);
String r="My father's name mohammad nasir";
        System.out.println(r);
String x="Iam from Bamyan";
        System.out.println(x);
String y="i study in the fuculty computer since";
        System.out.println(y);
String b="iam 19 years old";
        System.out.println(b);
        
    }

    
    
    
}
