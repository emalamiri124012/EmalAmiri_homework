
package javaapplication25;

import java.util.Random;
import java.util.Scanner;



public class JavaApplication25 {

    
    public static void main(String[] args) {
    Random random = new Random();
    double e =Math.round( random.nextDouble()*100);
      double r =Math.round( random.nextDouble()*100);
      Scanner scanner = new Scanner(System.in);


        System.out.print(e);
        System.out.print("+");
        System.out.println(r);
                System.out.println("please solve the up");
      double result = scanner.nextDouble();
      while (result != e+r){


      }
  
    }
    
}
