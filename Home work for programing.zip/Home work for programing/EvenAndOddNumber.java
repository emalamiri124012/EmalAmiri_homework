
package even.and.odd.number;


public class EvenAndOddNumber {

    public static void main(String[] args) {
  int x=9;
  if(x==0){System.out.println("the number is zero");
      
  }else if(x%2==0){
      System.out.println("the number is even");
  }else{
      System.out.println("the number is odd");
  }
    }
    
}
