
package javaapplication21;


public class JavaApplication21 {

  
    public static void main(String[] args) {
String namber="hussain";
String last="sharifi";
        System.out.println(namber+last );
    }
    
}
