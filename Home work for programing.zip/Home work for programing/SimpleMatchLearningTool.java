
package simple.match.learning.tool;
public class SimpleMatchLearningTool {
    public static void main(String[] args) {
//        Example one:
//int rand= (int)(Math.random()*10+10);
//int rand1=(int)(Math.random()*10);
//if(rand>rand1)
//        System.out.println(rand);
//       System.out.println(rand1);
//            System.out.println(rand+rand1);
//       int x=7;
//       int y=9;
//        System.out.println(x+y);
//   
//     Example two:   
//           int e=(int)(Math.random()*10);  
//              int r=(int)(Math.random()*10);    
//              if(e>r){
//                      System.out.println(e);
//                      System.out.println(r);
//                           System.out.println(e-r);
//              }
//                         System.out.println(9-2);

    }
    
}
