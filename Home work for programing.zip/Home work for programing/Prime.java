
import java.util.Scanner;


public class Prime{
    public static void main(String [] args){
        
        Scanner scanner = new Scanner(System.in);
        double p = scanner.nextDouble();
        double r1 = p%p;
        double r2 = p%1;
        if (r1 ==0 && r2==0 ){
            System.out.println(" it is prime value ");
        }else 
            System.out.println(" it is not prime");
    
    }
    
}
