
package javaapplication36;

import java.util.Scanner;

public class JavaApplication36 {

   
    public static void main(String[] args) {
       Scanner inpout=new Scanner(System.in) ;
       System.out.println("pleas enter the value ");
    double f=inpout.nextDouble();
    double c=(f-32)*5/9;
        System.out.println(c); 
        
        

    
}
}