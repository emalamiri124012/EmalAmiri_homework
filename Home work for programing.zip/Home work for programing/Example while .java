
package javaapplication24;

import java.util.Scanner;


public class JavaApplication24 {

    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
        System.out.println(" enter the word you want to rewrite it:");
        String  string = scanner.next();
        System.out.println("enter the value between 0  until 10:");
       int value;
        value= scanner.nextInt();
        
        while (value <10 ){
        System.out.println(string);
        value++;
    }
    }
    
}
