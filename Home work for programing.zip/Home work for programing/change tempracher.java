

package javaapplication23;

import java.util.Scanner;

public class JavaApplication23 {

    
    public static void main(String[] args) {
 
int c,f;
Scanner inpout = new Scanner(System.in);
        System.out.println("please enter the value");
f=inpout.nextInt();
 c=5*(f-32)/9;
        System.out.println(c);
   
   
   
   
   
   

        
     
     
     
     
     
     
     
     

        
       
    }
    
}
