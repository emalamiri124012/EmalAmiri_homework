
package convert.tempreacher;

import java.util.Scanner;

public class ConvertTempreacher {

    public static void main(String[] args) {
Scanner scanner =new Scanner(System.in);
//Example one:
//int c=scanner.nextInt();
//int f=(c+32)*(9/5);
//        System.out.println(f);

//Example two:
//int f =scanner.nextInt();
//int c=(f-32)*(9/5);
//        System.out.println(c);


    }
    
}
