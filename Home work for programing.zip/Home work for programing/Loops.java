package loops;

public class Loops {

    public static void main(String[] args) {

//                                                                             This example are about while or do while

//
//2:   example 2   loop

//int y=1;                           
//do{
//    System.out.println(y);
//    y++;
//    
//} while(y<=5);


//     3:  example 3   loop

//   int x=4;                                                                                                                                    
//   do{
//       System.out.println(x);
//       x++;
//   }while(x-4<=10);

//  4:  example 4   loop

//int e=1;                                                                  
//   do{
//  do {
//    System.out.println(e);
//    e++;
//}  while(e>=5); 


//   5:       example  5   loop 

//int r=1;     this loop is one cycle imposible                     
//   do     {
//    System.out.println(r);
//    r++;
//}while(r>=2);





//                                                                                                                   This example are about for   or for each   

//1: example 


//        for (int y = 1; y <= 10; y++) {                              
//            for (int x = 1; x <= 10; x++) {
//                System.out.print(x*y +"\t" );
//
//            }                             
//            System.out.println("");
//
//        } 
            // 
            
            
//     2: example 


//         for(int x=2;x<=100;x+=2){
//             System.out.println(x);
//         }


//3:example

//String   [     ]  name={"hussain","ali","mahdi","zahra","mohammad"};
//for(String x:name){
//    System.out.println(x);
//}




//4:example
    
//String  [  ] student={"Ahmad","Ali ", "Tawfiq","hussain"};  
//for(int x=0;x<4;x++)
//        System.out.println(student [x]);

//5:example
        
//for (int x=1;x<=10;x++){
//    
//    for(int y=1;y<=10;y++){
//           System.out.print(x*y  +"\t");
//    }
//      System.out.println();  
//    }
    }
}