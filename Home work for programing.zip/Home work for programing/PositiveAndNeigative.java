
package positive.and.neigative;
public class PositiveAndNeigative {

    public static void main(String[] args) {
int x=0;
if(x>0){
    System.out.println("positive");
}else if(x==0){
    System.out.println(" zero");
}else{
    System.out.println("neagative");
}
          
    }
    
}
