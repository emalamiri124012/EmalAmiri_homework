package exemple.pkgswitch;

import java.util.Scanner;

public class ExempleSwitch {

    public static void main(String[] args) {
        Scanner name = new Scanner(System.in);
//        int animle = name.nextInt();
//        switch (animle) {
//            case 0:
//                System.out.println("monkay");
//                break;
//            case 1:
//                System.out.println("rooster");
//                break;
//            case 2:
//                System.out.println("dog");
//                break;
//            case 3:
//                System.out.println("pig");
//                break;
//            case 4:
//                System.out.println("rat");
//                break;
//            case 5:
//                System.out.println("ox");
//                break;
//            case 6:
//                System.out.println("tiger");
//                break;
//            case 7:
//                System.out.println("rabit");
//                break;
//            case 8:
//                System.out.println("dragon");
//                break;
//            case 9:
//                System.out.println("snacke");
//                break;
//            case 10:
//                System.out.println("horse");
//                break;
//            case 11:
//                System.out.println("sheep");
//                break;
//            default:
//                System.out.println("this is incorect");
//        }
System.out.println("please enter the value");
//int week=name.nextInt();
//switch(week){
//    case 0:
//        System.out.println("satarday");
//        break;
//    case 1:
//        System.out.println("sunday");
//        break;
//           case 2:
//        System.out.println("monday");
//        break;
//           case 3:
//        System.out.println("teuesday");
//        break;
//           case 4:
//        System.out.println("wensday");
//        break;
//           case 5:
//        System.out.println("tersday");
//        break;
//              case 7:
//               System.out.println("friday");
//               break;
//              default:
//                  System.out.println("this are not week");
//               
//}


    }

}
