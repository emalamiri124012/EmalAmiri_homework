package javaapplication52;

public class JavaApplication52 {

    public static void main(String[] args) {
double x=8.3;
        System.out.println(Math.ceil(x));
        double y=5.2;
        System.out.println(Math.floor(y));
        double r=4.9;
        System.out.println(Math.round(r));
    }

}




