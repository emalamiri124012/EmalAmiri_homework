

package javaapplication14;


public class JavaApplication14 {


    public static void main(String[] args) {
  int x=2;
  int y=70;
        System.out.println(Math.sqrt(70));
       int e=12;
        System.out.println(Math.pow(e, x));
        
}}

    

