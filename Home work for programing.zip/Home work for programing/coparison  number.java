
package javaapplication33;

public class JavaApplication33 {


   
    public static void main(String[] args) {
int nume1=4;
int nume2=5;
        System.out.println("nume<nume");
        System.out.println("nume1>nume2");
        System.out.println("nume1<=nume2");
        System.out.println("nume1>=nume2");
        System.out.println("nume1=nume2");
        System.out.println("nume1!=nume2");
        
    
}
}