package javaapplication19;



public class JavaApplication19 {

    public static void main(String[] args) {
for(int number =1; number <=10; number ++ )
            System.out.println("Hellow world!");
{
    
}   
    }

}


