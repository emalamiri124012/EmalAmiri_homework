
package javaapplication32;

import java.util.Scanner;


public class JavaApplication32 {

    public static void main(String[] args) {
   Scanner  inpout =new Scanner(System.in) ;
        System.out.println("please enter the value");
   double r=inpout.nextInt();
   
final double pi=3.14;
double c=( pi*r*r);
        System.out.println(c); 
   
        
        
        
        
        
        
        
        
        
    }
}