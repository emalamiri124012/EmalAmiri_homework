
package scoore.number;

import java.util.Scanner;

public class ScooreNumber {

    public static void main(String[] args) {
        Scanner name=new Scanner (System.in);
int x=name.nextInt();
if(x>90&&x<=100){
    System.out.println("A");
}else if(x>75&&x<=90){
    System.out.println("B");   
}else if(x>65&&x<=75){
    System.out.println("C");
}else
            System.out.println("D");
 

    }}