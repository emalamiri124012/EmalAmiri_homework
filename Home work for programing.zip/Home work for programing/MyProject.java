
package my.project;

/**
 *
 * @author MAHBOOB COMPUTER
 */
public class MyProject {


    public static void main(String[] args) {
  char s='A';
        System.out.println(s);
  int x=100;
        System.out.println(x);
        
        
        
        
    }
    
}
