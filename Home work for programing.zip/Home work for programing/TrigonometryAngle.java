
package trigonometry.angle;

import java.util.Scanner;

public class TrigonometryAngle {

    public static void main(String[] args) {

 
    }
    
}