
package my.project.leap.year;

import java.util.Scanner;

public class MyProjectLeapYear {


    public static void main(String[] args) {
  Scanner scanner=new Scanner (System.in);
  int l=scanner.nextInt();
      if(l%4==0&&l%100==0||l%400==0)  {
          System.out.println("the number  is leap year");
      }else 
            System.out.println("the number is does't leap year");
          
        
        
        
        
    }
    
}
