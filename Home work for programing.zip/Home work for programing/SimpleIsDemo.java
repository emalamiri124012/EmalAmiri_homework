package simple.is.demo;

import java.util.Scanner;

public class SimpleIsDemo {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("please enter the value");
        int x = scanner.nextInt();
        int y = scanner.nextInt();
        if (x % 5 == 0) {
            System.out.println("the number is hifive");
        }       else if(x%5!=0){    
            System.out.println("the number is not hi five");
            }
        if (y % 2 == 0) {
            System.out.println("the number is hi two");

        } else {
            System.out.println("theis number is not hi two ");
        }
    }
}
