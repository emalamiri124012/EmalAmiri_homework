package the.problem.lottery;

import java.util.Scanner;

public class TheProblemLottery {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("please enter the value between 1 to 9");
    
        int x = scanner.nextInt();
         System.out.println("please enter the value between 1 to 9");
        int y = scanner.nextInt();

        int lottery1 = (int) (Math.random() * 10);
        System.out.println(lottery1);
        int lottery2 = (int) (Math.random() * 10);
        System.out.println(lottery2);
        if (x>=10 ||y >=10) {
            System.out.println("this number is not shamil in the interval");
//
//        } else if (lottery2 <= 10) {
//            System.out.println("this number is not shamil in the interval");
        } else if  ((x == lottery1 && y == lottery2)) {
            System.out.println("you win 10000 $");}

            else  if ((lottery1 == x||lottery2==x)||(lottery1== y||lottery2==y)) {
            System.out.println("you win 1000$");
        } else if (y == lottery1 && x == lottery2) {
            System.out.println("tou win 3000$");
        }else 
            System.out.println("you can not win");

    }

}
