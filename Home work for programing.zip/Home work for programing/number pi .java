

package javaapplication27;


public class JavaApplication27 {
    public static void main(String [] args ){
double pi=3.1415;
        System.out.println(pi);
    

   

        
    
      
            
     }
        
        
        
    }
    
