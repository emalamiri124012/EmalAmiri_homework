package example.lottery;

import java.util.Scanner;

public class ExampleLottery {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("please enter the value");
        int x = scanner.nextInt();
        int y = scanner.nextInt();

        int lottery1 = (int) (Math.random() * 90) + 10;
        System.out.println(lottery1);
        int lottery2 = (int) (Math.random() * 90) + 10;
        System.out.println(lottery2);
if(x==lottery1&&y==lottery2){
    System.out.println("this numbers equal lottery number you sacsesfully win 10000& ");
}else if(x==lottery2&&y==lottery1){
    System.out.println("you saccessfuly win 3000$");
}else if(x==lottery1||x==lottery2||y==lottery1||y==lottery2){
    System.out.println("once equal become  you win 1000$");
}else{
    System.out.println("you will not win ");
}
    }

}
