
package usearname.and.pasword;


public class UsearNameAndPasword {

    
    public static void main(String[] args) {
     String usearname="Mohammad";
     String paswoard="07988532428";
     if(usearname=="Mohammad"||paswoard=="07988533248"){
         System.out.println("ok welcome in the computer");
     }else{
         System.out.println("you can't go to the computer");
     }
    }
    
}
