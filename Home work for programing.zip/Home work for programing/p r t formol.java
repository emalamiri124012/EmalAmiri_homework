
package javaapplication38;

import java.util.Scanner;

public class JavaApplication38 {

    public static void main(String[] args) {
    
Scanner inpout=new Scanner(System.in);
        System.out.println("please  enter the value of p");
int p=inpout.nextInt();
  System.out.println("please  enter the value of r");
int r=inpout.nextInt();
  System.out.println("please  enter the value of t");
int t=inpout.nextInt();
int si=(p*r*t)/100;
        System.out.println(si);
        
        
        
        
    }
    
}
