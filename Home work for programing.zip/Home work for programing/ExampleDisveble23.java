
package example.disveble.pkg2.pkg3;

import java.util.Scanner;

public class ExampleDisveble23 {

    public static void main(String[] args) {
     Scanner scanner=new Scanner(System.in);
        System.out.println("please enter the value");
     int number1=scanner.nextInt();
     int number2=scanner.nextInt();
     if(number1%2==0&&number2%3==0){
         System.out.println("they are divisible by2,3");
     }   else if(number1%2==0||number2%3==0){
         System.out.println("they are divisible by 2 or 3");
     }else{
         System.out.println("they are not divisible");
     }

    }}
    

