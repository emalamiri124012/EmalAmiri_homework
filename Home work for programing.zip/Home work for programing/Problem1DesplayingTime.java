
package problem.pkg1.desplaying.time;

import java.util.Scanner;

 
public class Problem1DesplayingTime {

   
    public static void main(String[] args) {
//    int x=20;                                    
//    int y=x*60;
//        System.out.println(y);
Scanner scanner=new Scanner(System.in);
        System.out.println("please enter the value");
int x=scanner.nextInt();
        System.out.println(x*60);

    }
    
}
