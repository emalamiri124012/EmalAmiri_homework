package monetory.unit;

public class MonetoryUnit {
  public static void main(String[] args) {
//int d=4444;
//int c=d/4;
//        System.out.println(c);
//        int di =c/4;
//        System.out.println(di);
//        int ni  =di/5;
//        System.out.println(ni);
//        int pi=ni/10;
//        System.out.println(pi);


}
}
