
package javaapplication17;


public class JavaApplication17 {
String name ='Ahmad';
         
 
}
