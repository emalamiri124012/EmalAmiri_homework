
package trogonometry.angle;

import java.util.Scanner;

public class TrogonometryAngle {

    public static void main(String[] args) {
    Scanner scanner=new Scanner(System.in);
        System.out.println("please enter the value");
  int a=scanner.nextInt();
    int b=scanner.nextInt();
      int c=scanner.nextInt();
      double A=Math.acos((b*b+c*c-a*a)/(-2*b*c));
      double B=Math.acos((a*a+c*c-b*b)/(-2*a*c));
      double C=Math.acos((a*a+b*b-c*c)/(-2*a*b));
        System.out.println(A);
    System.out.println(B);
      System.out.println(C);
    }
    
}
