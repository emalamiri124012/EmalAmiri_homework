/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication12;

import java.util.Scanner;


public class JavaApplication12 {

    public static void main(String[] args) {
 Scanner t = new Scanner(System.in);
        System.out.println("inter the value of a");
     int a = t.nextInt();
     System.out.println("inter the value of e");
      int e = t.nextInt();
     
 if (e%2==0 && a%2==0){
            System.out.println("these are even vajue");
        }else if(e%2==0) { System.out.println("the e is even");
        }else if(a%2==0) { System.out.println("the a is even");
        }else System.out.println("these are noteven");
    }
    
}
