
package javaapplication40;

import java.util.Scanner;

public class JavaApplication40 {


    public static void main(String[] args) {
  
        Scanner scanner = new Scanner(System.in);
        System.out.println("enter the number of a :");
        double a = scanner.nextDouble();
        System.out.println("enter the number of b :");
        double b = scanner.nextDouble();
        
        System.out.println("enter the number of c :");
        double c = scanner.nextDouble();
        
        double d = b*b-4*a*c;
        if (d>=0){
        double x1 = (-b+Math.sqrt(d))/2.0*a;
        
         double x2 = (-b-Math.sqrt(d))/2.0*a;
         System.out.println("the x1 is :"+x1);
      System.out.println("the x2 is :"+x2);
    
}
        else {System.out.println("it does not have a root");}
}